/* stdarg.h */

#ifndef _VA_LIST_DEFINED
#define _VA_LIST_DEFINED
//#ifdef _M_ALPHA
//typedef struct {
//  char *a0;         /* pointer to first homed integer argument */
//  int offset;       /* byte offset of next parameter */
//} va_list;
//#else
typedef char *va_list;
//#endif
#endif

/*
 * define a macro to compute the size of a type, variable or expression,
 * rounded up to the nearest multiple of sizeof(int).
 * This number is its size as function argument (Intel architecture).
 * Note that the macro depends on sizeof(int) being a power of 2!
 */
#define _INTSIZEOF(n) ((sizeof(n) + sizeof(int) - 1) & ~(sizeof(int) - 1))

#define va_dcl va_list va_alist;
#define va_start(ap) ap = (va_list)&va_alist
#define va_arg(ap,t) ( *(t*)((ap += _INTSIZEOF(t)) - _INTSIZEOF(t)) )
#define va_end(ap) ap = (va_list)0
