/*
Copyright (c) 1984, 1985, 1986, 1987, 1988 AT&T
	All Rights Reserved

Note: This software was created by the Bell Laboratories unit of AT&T.
Bell Laboratories was subsequently part of Lucent Technologies, later part of
Alcatel-Lucent, and now part of Nokia; some copyrights may have been assigned
by AT&T to its successors. This license is granted by Nokia solely to the
extent of its right to do so.
*/

# define FINAL 269
# define DOT 270
# define ALL 271
# define CCL 272
# define NCCL 273
# define CHAR 274
# define OR 275
# define STAR 276
# define QUEST 277
# define PLUS 278
# define CAT 342
