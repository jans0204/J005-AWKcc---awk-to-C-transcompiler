/*
Copyright (c) 1984, 1985, 1986, 1987, 1988 AT&T
	All Rights Reserved

Note: This software was created by the Bell Laboratories unit of AT&T.
Bell Laboratories was subsequently part of Lucent Technologies, later part of
Alcatel-Lucent, and now part of Nokia; some copyrights may have been assigned
by AT&T to its successors. This license is granted by Nokia solely to the
extent of its right to do so.
*/

# define FINAL 268
# define DOT 269
# define ALL 270
# define CCL 271
# define NCCL 272
# define CHAR 273
# define OR 274
# define STAR 275
# define QUEST 276
# define PLUS 277
# define CAT 342
